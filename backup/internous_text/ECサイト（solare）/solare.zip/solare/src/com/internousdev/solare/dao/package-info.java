/**
 * トランザクショナルな操作、つまり生成、更新、削除などを行う為のパッケージ
 * @version 1.0
 * @since 2016/04/18
 */
package com.internousdev.solare.dao;