/**
 * 画面（View）からリクエストを受取り、次に表示する画面の決定する為のパッケージ
 * @version 1.0
 * @since 2016/04/18
 */
package com.internousdev.solare.action;