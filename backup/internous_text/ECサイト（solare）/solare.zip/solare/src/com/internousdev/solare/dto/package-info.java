/**
 * 関連するデータを一つにまとめ、データの格納・読み出しを行う為のパッケージ
 * @version 1.0
 * @since 2016/04/18
 */
package com.internousdev.solare.dto;